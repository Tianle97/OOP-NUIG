package setup;

import java.io.File;
import java.io.IOException;
import java.time.Year;
import java.util.Scanner;
import java.util.TreeSet;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import setup.models.Event;
import setup.models.EventCollection;
import setup.models.SubEvent;
import setup.models.TimeLine;

public class Application {

	public static void main(String[] args) {
		// create a scanner let user input the information.
		Scanner input = new Scanner(System.in);

		// let people choose a year or a range of 2 years
		System.out.println("input 1 for one year search, input a range of 2 years :");
		int num = input.nextInt();
		int startYear;
		int endYear;
		if (num == 1) {
			System.out.println("plaese input the Year : ");
			startYear = input.nextInt();
			endYear = startYear + 1;
		} else {
			System.out.println("plaese input the start Year : ");
			startYear = input.nextInt();

			System.out.println("plaese input the end Year : ");
			endYear = input.nextInt();
		}

		ObjectMapper mapper = new ObjectMapper();

		try {
			// read value from json file
			EventCollection eventCollection = mapper.readValue(new File("assignment_2_data.json"),
					EventCollection.class);
			// from singleton pattern create a new object timeline
			TimeLine tl = TimeLine.getInstance();
			// let the readValue store into treemap so call this method
			tl.populateTimeline(eventCollection);

			// swap the from year and end year (when end year earlier than from year)
			if (startYear > endYear) {
				int temp = startYear;
				startYear = endYear;
				endYear = temp;
				System.out.println("Please let start year earlier end year, Anyway I swap these two year.");
			}

			// print the result.
			printResult(tl, startYear, endYear);

		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// close scanner stream
		input.close();

	}

	@SuppressWarnings("unchecked")
	private static void printResult(TimeLine tl, int startYear, int endYear) {
		TreeSet<Event> ts = new TreeSet<Event>();
		// use java.util.TreeMap.subMap(K startKey, K endKey)
		// reference:https://www.geeksforgeeks.org/treemap-submap-method-in-java/
		for (int i = 0; i < tl.getEventMap().subMap(Year.of(startYear), Year.of(endYear + 1)).size(); i++) {
			ts = (TreeSet<Event>) tl.getEventMap().subMap(Year.of(startYear), Year.of(endYear + 1)).values()
					.toArray()[i];
			for (Event e : ts) {
				System.out.println(
						"events:\n name: " + e.getName() + "\n type: " + e.getType() + "\n year: " + e.getYear());
				for (SubEvent se : e.getSubevents()) {
					System.out.println(" subenvent:\n   name: " + se.getName() + "\n   year: " + se.getYear());
				}
			}
		}
	}

}
