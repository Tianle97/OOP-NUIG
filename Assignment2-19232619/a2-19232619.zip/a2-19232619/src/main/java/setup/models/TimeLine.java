package setup.models;

import java.time.Year;
import java.util.TreeMap;
import java.util.TreeSet;

public class TimeLine {
	private TreeMap<Year, TreeSet<Event>> eventsMap = new TreeMap<Year, TreeSet<Event>>();
	// singleton design pattern
	private static TimeLine instance;

	protected TimeLine() {
	}

	public static TimeLine getInstance() {
		if (instance == null) {
			instance = new TimeLine();
		}
		return instance;
	}

	public TreeMap<Year, TreeSet<Event>> getEventMap() {
		return eventsMap;
	}

	public void addEventMpa(Year y, TreeSet<Event> e) {
		eventsMap.put(y, e);
	}

	// this method is let the TreeSet<Event> into TreeMap<Year,TreeSet<Event>>
	public void populateTimeline(EventCollection ec) {
		for (Event e : ec.getEvents()) {
			Year y = e.getYear();
			if (eventsMap.containsKey(y)) {
				eventsMap.get(y).add(e);
				TreeSet<Event> tse = eventsMap.get(y);
				addEventMpa(e.getYear(), tse);

			} else {

				TreeSet<Event> tse = new TreeSet<Event>();
				tse.add(e);
				addEventMpa(y, tse);

			}
		}
		// for debug
		// System.out.println("success store into the map");
	}
}
