package setup.models;

public class SubEvent extends Container {
	// in here we can add some new unique attributes for the subevent class.
	public SubEvent() {
	}
}
