package setup.models;

import java.util.TreeSet;

public class EventCollection {
	private TreeSet<Event> events = new TreeSet<Event>();

	public TreeSet<Event> getEvents() {
		return events;
	}

	public void addEvent(Event e) {
		events.add(e);
	}

	public void setEvents(TreeSet<Event> events) {
		for (Event e : events) {
			try {
				e.checkYear();
			} catch (IllegalAccessException err) {
				System.out.println("Entry " + err + " was removed");
			}
		}
		this.events = events;
	}

}
