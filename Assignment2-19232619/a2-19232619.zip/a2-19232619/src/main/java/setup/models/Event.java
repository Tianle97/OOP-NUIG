package setup.models;

import java.time.Year;
import java.util.TreeSet;

public class Event extends Container {
	private TreeSet<SubEvent> subevents = new TreeSet<SubEvent>();

	public TreeSet<SubEvent> getSubevents() {
		return subevents;
	}

	public void setSubEvent(TreeSet<SubEvent> subevents) {
		this.subevents = subevents;
	}

	public void addSubEvent(SubEvent s) {
		subevents.add(s);

	}

	//throw a IllegalAccessException to tell people 
	public void checkYear() throws IllegalAccessException {
		for (SubEvent se : subevents) {
			Year sy = se.getYear();
			Year y = getYear();
			if (sy.compareTo(y) < 0) {
				subevents.remove(se);
				throw new IllegalAccessException(
						"Event name: " + getName() + "subevent name: " + se.getName() + " " + se.getYear().toString());
			}
		}

	}

}
