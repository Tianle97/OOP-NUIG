package setup.models;

import java.time.Year;

public abstract class Container implements Comparable<Container> {
	private String name;
	private String type;
	private Year year;

	public Container() {
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Year getYear() {
		return year;
	}

	public void setYear(Year year) {
		this.year = year;
	}

	public int compareTo(Container o) {
		return this.getYear().compareTo(o.getYear());

	}

}
